"""Draw zone perimeters and live detections onto a frame, so you can see them.

Perimeters are normalised 0-1 coordinates typed into a form. That is workable
but blind, and being blind about it goes wrong quietly: a polygon over the wrong
part of the scene matches nothing and looks exactly like a pipeline with nothing
to report. This turns that into something you can look at.

Written after drawing two perimeters by guessing, watching one collect every
detection and the other collect none, and only understanding why after seeing
them on the image. It is the cheap stand-in for the drawing tool the
specification eventually wants.

    python zone_preview.py --frame 700 --out preview.png
    python zone_preview.py --camera driveway --no-detect
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys
from pathlib import Path

import cv2
import numpy as np
import yaml

from perception.api_client import ApiClient

HERE = Path(__file__).parent

# Distinct hues rather than a gradient: these label categories, not magnitudes.
ZONE_COLOURS = [
    (90, 200, 90),
    (200, 140, 60),
    (90, 120, 230),
    (200, 90, 200),
    (60, 200, 200),
]


def load_clip_path(camera: str) -> Path:
    config = yaml.safe_load((HERE / "cameras.yaml").read_text()) or {}
    cameras = config.get("cameras") or {}
    if camera not in cameras:
        raise SystemExit(f"no camera {camera!r} in cameras.yaml (have: {', '.join(cameras)})")
    clip = Path(cameras[camera]["clip"])
    return clip if clip.is_absolute() else HERE / clip


def read_frame(clip: Path, index: int):
    """Decode sequentially to `index`.

    Not a seek: some research footage is in inter-frame codecs where seeking to
    an arbitrary frame returns corrupt tiles (Indeo 5 does exactly this).
    """
    cap = cv2.VideoCapture(str(clip))
    frame = None
    for i in range(index + 1):
        ok, current = cap.read()
        if not ok:
            break
        if i == index:
            frame = current
    cap.release()
    if frame is None:
        raise SystemExit(f"could not read frame {index} from {clip.name}")
    return frame


async def fetch_perimeters(camera: str):
    api = ApiClient()
    try:
        index = await api.fetch_zone_index()
    finally:
        await api.aclose()
    return [p for p in getattr(index, "_by_camera", {}).get(camera, [])]


def render(frame, perimeters, detections, scale: int = 2):
    canvas = cv2.resize(
        frame,
        (frame.shape[1] * scale, frame.shape[0] * scale),
        interpolation=cv2.INTER_NEAREST,
    )
    height, width = canvas.shape[:2]

    fill = canvas.copy()
    for i, perimeter in enumerate(perimeters):
        colour = ZONE_COLOURS[i % len(ZONE_COLOURS)]
        points = np.array(
            [[int(x * width), int(y * height)] for x, y in perimeter.polygon], np.int32
        )
        cv2.fillPoly(fill, [points], colour)
        cv2.polylines(canvas, [points], True, colour, 2)
        cv2.putText(
            canvas, perimeter.zone_name, tuple(points[0] + [6, 20]),
            cv2.FONT_HERSHEY_SIMPLEX, 0.5, colour, 1,
        )
    # Translucent, so the footage underneath stays readable — the whole point is
    # to judge the polygon against what is actually in the scene.
    canvas = cv2.addWeighted(fill, 0.22, canvas, 0.78, 0)

    for detection in detections:
        x1, y1, x2, y2 = (int(v * scale) for v in detection.box)
        cv2.rectangle(canvas, (x1, y1), (x2, y2), (255, 255, 255), 1)
        # The centroid is marked because it, not the box, is what L3 tests
        # against a polygon — and near a boundary that difference decides.
        cv2.drawMarker(
            canvas, ((x1 + x2) // 2, (y1 + y2) // 2), (0, 0, 255),
            cv2.MARKER_CROSS, 12, 2,
        )
        cv2.putText(
            canvas, f"{detection.label} {detection.confidence:.2f}", (x1, y1 - 4),
            cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1,
        )
    return canvas


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--camera", default="passageway")
    parser.add_argument("--frame", type=int, default=700)
    parser.add_argument("--out", default="zone_preview.png")
    parser.add_argument("--scale", type=int, default=2)
    parser.add_argument(
        "--no-detect", action="store_true", help="skip inference; draw perimeters only"
    )
    args = parser.parse_args()

    frame = read_frame(load_clip_path(args.camera), args.frame)
    perimeters = asyncio.run(fetch_perimeters(args.camera))

    detections = []
    if not args.no_detect:
        try:
            from perception.pipeline.detect import RTDetrDetector

            detections = RTDetrDetector().detect(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        except ImportError:
            # Perimeters are the point of this tool and they need no model, so a
            # missing torch degrades the output rather than failing the run.
            # Installing several gigabytes to draw polygons would be a poor trade.
            print("  (no detector installed — drawing perimeters only)")
            print("  for detections: uv sync --extra detect  in estate-sentry-perception")

    canvas = render(frame, perimeters, detections, scale=args.scale)
    cv2.imwrite(args.out, canvas)

    print(f"{args.out}: {len(perimeters)} perimeter(s), {len(detections)} detection(s)")
    if not perimeters:
        print(
            f"  no perimeters for {args.camera!r} — check API_URL and "
            "PERCEPTION_API_TOKEN, and that a ZonePerimeter exists for this camera"
        )
    height, width = frame.shape[:2]
    for detection in detections:
        cx, cy = detection.centroid
        print(f"  {detection.label:8} centroid = ({cx / width:.2f}, {cy / height:.2f})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
