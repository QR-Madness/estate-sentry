"""Mock camera rig — replays video files as if they were live cameras.

Stands in for the Raspberry Pi edge agent during development. It publishes on
exactly the contract the real agent will use, imported from the perception
package rather than restated here, so the two cannot drift:

    frame bytes  ->  object store at  frames/{camera_id}/{date}/{iso}.jpg
    notification ->  bus subject      frames.{camera_id}.raw

Swapping this for real hardware is therefore a change of producer and nothing
else — the pipeline never learns where its frames came from.

    python mock_camera.py                 # replay every camera in cameras.yaml
    python mock_camera.py --dry-run       # decode and report, publish nothing
    python mock_camera.py --camera front_door
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import signal
import sys
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

import cv2
import yaml

from perception.constants import DEFAULT_CAPTURE_FPS, JPEG_QUALITY
from perception.transport import FrameRef, frame_key, frame_subject
from perception.transport.minio_store import MinioFrameStore
from perception.transport.nats_bus import NatsEventBus

logger = logging.getLogger("mock_camera")

HERE = Path(__file__).parent
DEFAULT_CONFIG = HERE / "cameras.yaml"


@dataclass(frozen=True, slots=True)
class CameraConfig:
    camera_id: str
    clip: Path
    fps: float = DEFAULT_CAPTURE_FPS
    loop: bool = True
    #: Whether to advertise a producer-side motion hint. Left False by default so
    #: the pipeline's own L1 gate is what gets exercised — a mock that always
    #: claimed motion would make the gate untestable in situ.
    emit_motion_hint: bool = False

    @classmethod
    def from_dict(cls, camera_id: str, raw: dict) -> CameraConfig:
        clip = Path(raw["clip"])
        if not clip.is_absolute():
            clip = HERE / clip
        return cls(
            camera_id=camera_id,
            clip=clip,
            fps=float(raw.get("fps", DEFAULT_CAPTURE_FPS)),
            loop=bool(raw.get("loop", True)),
            emit_motion_hint=bool(raw.get("emit_motion_hint", False)),
        )


def load_config(path: Path) -> list[CameraConfig]:
    if not path.exists():
        raise SystemExit(f"no config at {path}. Copy cameras.example.yaml first.")
    raw = yaml.safe_load(path.read_text()) or {}
    cameras = raw.get("cameras") or {}
    if not cameras:
        raise SystemExit(f"{path} defines no cameras.")
    return [CameraConfig.from_dict(cid, cfg) for cid, cfg in cameras.items()]


class ClipReader:
    """Decodes a video file frame by frame, optionally looping.

    OpenCV's capture API is blocking and not thread-safe, so a reader is owned by
    exactly one task and every call is offloaded with `asyncio.to_thread`.
    Decoding on the event loop would stall every other camera and the shutdown
    handler along with them.

    **Frames are skipped to preserve real-time motion.** Emitting consecutive
    frames at the target rate would replay the clip in slow motion: a 15 fps
    source emitted at 5 fps shows a third of the real movement between frames.
    That is not a cosmetic difference — the motion gate measures exactly that
    inter-frame delta, so slow-motion playback under-reports movement and the
    gate closes on footage a real camera would have passed. Observed directly:
    a walking figure registered 0.0012 changed area against a 0.002 threshold.

    So the reader advances `native_fps / target_fps` frames per emission, which
    is what a real camera sampling at the target rate would see.
    """

    def __init__(self, clip: Path, *, loop: bool, target_fps: float) -> None:
        if not clip.exists():
            raise SystemExit(f"clip not found: {clip}")
        self._capture = cv2.VideoCapture(str(clip))
        if not self._capture.isOpened():
            raise SystemExit(f"could not open clip (unsupported codec?): {clip}")
        self._clip = clip
        self._loop = loop

        native_fps = self._capture.get(cv2.CAP_PROP_FPS) or target_fps
        self.native_fps = native_fps
        # At least 1: a clip slower than the target rate cannot be sped up, and
        # a stride of 0 would spin without advancing.
        self.stride = max(1, round(native_fps / target_fps))

    def _rewind(self) -> None:
        self._capture.set(cv2.CAP_PROP_POS_FRAMES, 0)

    def _read_sync(self):
        # `grab()` decodes nothing, so skipping is far cheaper than reading.
        for _ in range(self.stride - 1):
            if not self._capture.grab():
                if not self._loop:
                    return None
                self._rewind()
                break

        ok, frame = self._capture.read()
        if not ok:
            if not self._loop:
                return None
            self._rewind()
            ok, frame = self._capture.read()
            if not ok:
                return None
        return frame

    async def read(self):
        return await asyncio.to_thread(self._read_sync)

    def release(self) -> None:
        self._capture.release()


def encode_jpeg(frame) -> bytes:
    ok, buffer = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY])
    if not ok:  # pragma: no cover
        raise RuntimeError("JPEG encoding failed")
    return buffer.tobytes()


async def run_camera(
    config: CameraConfig,
    store: MinioFrameStore | None,
    bus: NatsEventBus | None,
    *,
    stop: asyncio.Event,
) -> None:
    """Replay one clip until `stop` is set."""
    reader = ClipReader(config.clip, loop=config.loop, target_fps=config.fps)
    interval = 1.0 / config.fps
    published = 0

    logger.info(
        "%s: replaying %s at %.1f fps (source %.1f fps, stride %d)",
        config.camera_id,
        config.clip.name,
        config.fps,
        reader.native_fps,
        reader.stride,
    )
    try:
        while not stop.is_set():
            tick = asyncio.get_running_loop().time()

            frame = await reader.read()
            if frame is None:
                logger.info("%s: clip exhausted", config.camera_id)
                break

            height, width = frame.shape[:2]
            captured_at = datetime.now(UTC)
            key = frame_key(config.camera_id, captured_at)

            ref = FrameRef(
                camera_id=config.camera_id,
                path=key,
                captured_at=captured_at,
                width=width,
                height=height,
                motion_detected=True if config.emit_motion_hint else None,
            )

            if store is not None and bus is not None:
                await store.put(key, encode_jpeg(frame))
                await bus.publish(frame_subject(config.camera_id), ref.to_json())
            published += 1

            if published % 25 == 0:
                logger.info("%s: %d frames published", config.camera_id, published)

            # Sleep the remainder of the interval rather than a flat `interval`,
            # so encode and upload time does not silently halve the frame rate.
            elapsed = asyncio.get_running_loop().time() - tick
            await asyncio.sleep(max(0.0, interval - elapsed))
    finally:
        reader.release()
        logger.info("%s: stopped after %d frames", config.camera_id, published)


async def main_async(args: argparse.Namespace) -> int:
    cameras = load_config(Path(args.config))
    if args.camera:
        cameras = [c for c in cameras if c.camera_id == args.camera]
        if not cameras:
            raise SystemExit(f"no camera named {args.camera!r} in the config")

    store: MinioFrameStore | None = None
    bus: NatsEventBus | None = None

    if args.dry_run:
        logger.warning("dry run: decoding only, nothing will be published")
    else:
        store = MinioFrameStore.from_env()
        await store.ensure_bucket()
        bus = await NatsEventBus.connect()

    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, stop.set)

    try:
        await asyncio.gather(
            *(run_camera(c, store, bus, stop=stop) for c in cameras)
        )
    finally:
        if bus is not None:
            await bus.close()
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--camera", help="replay only this camera id")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="decode and report without publishing (needs no MinIO or NATS)",
    )
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
    )
    try:
        return asyncio.run(main_async(args))
    except KeyboardInterrupt:  # pragma: no cover
        return 130


if __name__ == "__main__":
    sys.exit(main())
