# Mock Estate

A stand-in for the Raspberry Pi edge agent. Replays video files as if they were
live cameras, publishing on the same contract the real hardware will use.

This lives in the workspace rather than the repo, deliberately: the footage is
large and separately licensed, and none of it should enter git history.

## Why it exists

The perception pipeline needs frames before there is a camera to produce them.
Rather than build a throwaway harness, this rig publishes on the **real** contract
from `docs/Specification.md`:

```
frame bytes  ->  object store at  frames/{camera_id}/{date}/{iso}.jpg
notification ->  bus subject      frames.{camera_id}.raw
```

Those helpers are imported from `perception.transport`, not restated here, so the
mock and the pipeline cannot drift apart. Replacing this with the Pi is a change
of producer and nothing else.

## Setup

```bash
uv sync
cp cameras.example.yaml cameras.yaml
```

Then put clips in `footage/` and point `cameras.yaml` at them.

Decoding uses `opencv-python-headless`, which bundles its own FFmpeg — no system
`ffmpeg` is required.

## Running

Start the transport first (from the repo):

```bash
docker compose up -d nats minio
```

Then:

```bash
uv run python mock_camera.py                    # every camera in cameras.yaml
uv run python mock_camera.py --camera front_door
uv run python mock_camera.py --dry-run          # decode only, no infrastructure needed
```

`--dry-run` decodes and reports without publishing, which is the quickest way to
check a clip is readable and the config is right before involving MinIO or NATS.

Stop with Ctrl-C; both signals are handled and each reader is released.

## Checking zones

`zone_preview.py` draws zone perimeters, and optionally live detections, onto a
frame from a clip:

```bash
uv run python zone_preview.py --frame 700 --out preview.png
```

Perimeters are normalised 0-1 coordinates typed into a form, which is workable
but blind — and blind goes wrong quietly. A polygon over the wrong part of the
scene matches nothing and looks exactly like a pipeline with nothing to report.

That is not hypothetical. The first two perimeters here were drawn by guessing:
one collected every detection and the other collected none, and the reason was
only obvious once they were drawn on the image. In the passageway footage the
foot traffic runs along the far wall at the top of frame, while the large floor
in the foreground stays empty for the whole clip — the opposite of what the
name "walkway" suggests.

The red cross marks each detection's **centroid**, because that, not the box, is
what L3 tests against a polygon. Near a boundary the difference decides the
answer.

Detections need the perception `detect` extra; without it the tool still draws
perimeters and says so.

## Footage

**Record the source and licence of every clip here.** Nothing in `footage/` is
committed, so this table is the only provenance record.

| File | Source | Licence | Notes |
|------|--------|---------|-------|
| `passageway1-c0.avi` | [EPFL CVLAB Multi-camera Pedestrian Videos](https://www.epfl.ch/labs/cvlab/data/data-pom-index-php/) | CVLab–EPFL, research use | 360x288, 25 fps, 2500 frames (100s), Indeo 5. Fixed camera in an underground passageway. Subjects are lab members who consented, so no privacy concern. Deliberately poorly lit — a hard case, not an easy one. |
| `synthetic.mp4` | `make_synthetic_clip.py` | n/a (generated) | Deterministic; a block crossing a static scene with a loiter phase. |
| `still.mp4` | `make_synthetic_clip.py --still` | n/a (generated) | Background only. Negative control: the motion gate must stay shut. |

### Codec caveats

Some research datasets ship in old codecs. EPFL's are Indeo 5 (`IV50`), which
`opencv-python-headless` decodes via its bundled FFmpeg — no system install
needed.

One trap: Indeo 5 is inter-frame compressed, so **seeking to an arbitrary frame
produces corrupt output** ("Corrupted tile data encountered", then a `None`
frame). Seeking to frame 0 is fine, because it is a keyframe, so the loop path
in `ClipReader` is safe. Anything that needs a specific frame must decode
sequentially to reach it.

Also worth checking: verify a download has *finished* before using it. A
truncated AVI opens happily and reports the full frame count from its header,
then stops decoding partway — which looks like a codec bug rather than an
incomplete file.

### Choosing clips

What makes footage useful here is not resolution but framing. Aim for:

- **A fixed camera.** The L1 motion gate differences consecutive frames, so a
  handheld or panning shot reads as continuous motion and the gate never closes.
- **An exterior, elevated, wide view** — a driveway, path, or doorway. This is
  what the zone model in the specification assumes.
- **People entering and leaving frame**, rather than filling it. Detection and,
  later, tracking are more interesting across a boundary than in close-up.
- **A few minutes at most.** It loops.

### Licensing

Use public-domain or CC0 sources. Ordinary online video is a poor fit: "fair use"
does not cleanly cover ingesting and redistributing third-party footage, and
nothing here needs it to. Reasonable sources are archive.org's public-domain
collections, CC0 stock libraries such as Pexels, and CV research datasets released
for exactly this purpose.

Avoid footage of identifiable people where the licence does not cover it — this is
a surveillance system, and testing it on people who did not consent to appear is
the wrong habit to build early.

### Synthetic clips

`make_synthetic_clip.py` generates a deterministic clip — a shape crossing a static
background — with no download and no licensing question at all. It exercises the
full path (decode, encode, store, publish, motion gate) and is what the pipeline
tests run against. It teaches the detector nothing, so it complements real footage
rather than replacing it.

```bash
uv run python make_synthetic_clip.py footage/synthetic.mp4
```
