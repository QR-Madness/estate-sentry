"""Generate a deterministic test clip — no download, no licensing question.

A static background with a shape crossing it. That is enough to exercise the
entire path (decode, encode, store, publish, motion gate) and, unlike real
footage, it is reproducible: the same command always yields the same frames, so a
test that fails did so because the code changed.

It teaches the detector nothing — a rectangle is not a person — so it complements
real footage rather than replacing it.

    python make_synthetic_clip.py footage/synthetic.mp4
    python make_synthetic_clip.py footage/still.mp4 --still
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np

WIDTH, HEIGHT = 640, 480


def background() -> np.ndarray:
    """A static scene with enough texture to be a fair motion-gate baseline.

    A flat colour would make the gate look better than it is: any change at all
    would stand out. Gradient plus fixed noise is a more honest floor.
    """
    rng = np.random.default_rng(seed=1234)  # fixed, so the clip is reproducible
    gradient = np.linspace(40, 110, HEIGHT, dtype=np.uint8)
    frame = np.repeat(gradient[:, None], WIDTH, axis=1)
    frame = np.stack([frame] * 3, axis=-1)

    noise = rng.integers(-6, 7, size=frame.shape, dtype=np.int16)
    frame = np.clip(frame.astype(np.int16) + noise, 0, 255).astype(np.uint8)

    # A horizon line and a doorway, so the scene reads as a place.
    cv2.line(frame, (0, 330), (WIDTH, 330), (70, 70, 75), 2)
    cv2.rectangle(frame, (60, 190), (150, 330), (95, 90, 85), -1)
    return frame


def write_clip(path: Path, *, seconds: int, fps: int, still: bool) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    scene = background()
    total = seconds * fps

    writer = cv2.VideoWriter(
        str(path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (WIDTH, HEIGHT)
    )
    if not writer.isOpened():
        raise SystemExit(f"could not open a writer for {path}")

    try:
        for i in range(total):
            frame = scene.copy()
            if not still:
                # A figure-sized block crossing left to right, pausing in the
                # middle third — so the clip contains both motion and dwell,
                # which are different things to the pipeline.
                progress = i / total
                if progress < 0.4:
                    x = int(progress / 0.4 * (WIDTH * 0.45))
                elif progress < 0.6:
                    x = int(WIDTH * 0.45)  # loiter
                else:
                    x = int(WIDTH * 0.45 + (progress - 0.6) / 0.4 * (WIDTH * 0.55))
                cv2.rectangle(
                    frame, (x, 250), (x + 45, 340), (190, 185, 180), -1
                )
            writer.write(frame)
    finally:
        writer.release()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--seconds", type=int, default=20)
    parser.add_argument("--fps", type=int, default=15)
    parser.add_argument(
        "--still",
        action="store_true",
        help="background only — useful for checking the motion gate stays closed",
    )
    args = parser.parse_args()

    write_clip(args.output, seconds=args.seconds, fps=args.fps, still=args.still)
    size_kb = args.output.stat().st_size / 1024
    print(
        f"wrote {args.output} — {args.seconds}s @ {args.fps}fps, "
        f"{WIDTH}x{HEIGHT}, {size_kb:.0f} KB"
        + (" (static)" if args.still else "")
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
